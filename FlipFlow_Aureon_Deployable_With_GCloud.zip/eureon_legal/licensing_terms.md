# Licensing Terms
Strictly owned by Darcel King.